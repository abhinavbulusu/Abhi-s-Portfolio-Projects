# The-Third-Eye
Features and items that should be still have to be implemented in order:
1. Location Feature
2. Emails to TSBVI and other school for the blind
3. AI for reading ingredients due to allergies and other concerns
